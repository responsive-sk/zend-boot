<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @app/index.html.twig */
class __TwigTemplate_58258f17bc6d72e5458cfbd4b9de5a36 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "@layout/default.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("@layout/default.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "A PSR-15 compliant application";
        yield from [];
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 6
        yield "    <div class=\"page-intro home-intro\">
        <div class=\"container\">
            <p class=\"welcome\">Dotkernel Light is a basic</p>
            <h1>PSR-15 Middleware skeleton</h1>
            <p>Built on top of the Mezzio microframework. <br/>Composed of a set of custom and extended Laminas components.</p>
        </div>
        <div class=\"arrow_down\">
            <div class=\"arrow_down_content\">&nbsp;</div>
        </div>
    </div>

    <div class=\"home-list\">
        <div class=\"container\">
            <h2><a href=\"https://docs.mezzio.dev/mezzio/\" target=\"_blank\" class=\"text-decoration-none\">Mezzio</a></h2>
            <div class=\"row\">
                <div class=\"col-lg-3 col-md-6\">
                    <h3>
                        <a href=\"https://github.com/php-fig/container\" target=\"_blank\" class=\"text-decoration-none\">containers</a>
                    </h3>
                    <p>
                        Dotkernel is built around the PSR-11 dependency container.
                        We have chosen <b>Laminas Service Manager</b> as our default implementation.
                    </p>
                    <p>
                        Get Started with
                        <br />
                        <a href=\"https://github.com/php-fig/container\" target=\"_blank\" class=\"text-decoration-none\">PSR-11</a>
                        and
                        <a href=\"https://github.com/laminas/laminas-servicemanager\" target=\"_blank\" class=\"text-decoration-none\">Laminas Service Manager</a>
                    </p>
                </div>
                <div class=\"col-lg-3 col-md-6\">
                    <h3>
                        <a href=\"https://github.com/twigphp/Twig\" target=\"_blank\" class=\"text-decoration-none\">templating</a>
                    </h3>
                    <p>
                        By default, no middleware in Laminas is templated.
                        For Dotkernel's Light application, we have chosen <b>Twig</b> as the default templating engine.
                    </p>
                    <p>
                        Get started with
                        <br />
                        <a href=\"https://twig.symfony.com/\" target=\"_blank\" class=\"text-decoration-none\">Twig</a>
                        and
                        <a href=\"https://github.com/mezzio/mezzio-twigrenderer\" target=\"_blank\" class=\"text-decoration-none\">Mezzio TwigRenderer</a>
                    </p>
                </div>

                <div class=\"col-lg-3 col-md-6\">
                    <h3>
                        <a href=\"https://github.com/nikic/FastRoute\" target=\"_blank\" class=\"text-decoration-none\">routers</a>
                    </h3>
                    <p>
                        Among the various routing implementations compatible with Expressive, we have chosen <b>FastRoute</b> as Dotkernel's default routing library.
                    </p>
                    <p>
                        Get started with
                        <br />
                        <a href=\"https://github.com/nikic/FastRoute\" target=\"_blank\" class=\"text-decoration-none\">FastRoute</a>
                    </p>
                </div>
                <div class=\"col-lg-3 col-md-6\">
                    <h3>
                        <a href=\"https://github.com/laminas/laminas-diactoros\" target=\"_blank\" class=\"text-decoration-none\">http messages</a>
                    </h3>
                    <p>
                        Laminas, and consequently Dotkernel, is built around the PSR-7 standard.<br />It uses <b>Laminas Diactoros</b> as the PSR-7 implementation.
                    </p>
                    <p>
                        Get started with
                        <br />
                        <a href=\"https://github.com/php-fig/http-message\" target=\"_blank\" class=\"text-decoration-none\">PSR-7</a>
                        and
                        <a href=\"https://github.com/laminas/laminas-diactoros\" target=\"_blank\" class=\"text-decoration-none\">Laminas Diactoros</a>
                    </p>
                </div>
            </div>

            <h2>Dotkernel Light components</h2>
            <div class=\"row\">
                <div class=\"col-md-12 text-start\">
                    <ul class=\"list-unstyled list-group list-group-flush\">
                        <li class=\"list-group-item\">
                            <a href=\"https://github.com/dotkernel/dot-log\" target=\"_blank\" class=\"text-decoration-none\">dot-log</a>: generic logging component
                        </li>
                        <li class=\"list-group-item\">
                            <a href=\"https://github.com/dotkernel/dot-errorhandler\" target=\"_blank\" class=\"text-decoration-none\">dot-errorhandler</a>: error logging component
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@app/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  70 => 6,  63 => 5,  52 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@app/index.html.twig", "/home/dan/Desktop/07/dk/light/src/App/templates/app/index.html.twig");
    }
}
