<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @layout/default.html.twig */
class __TwigTemplate_7498e7bf68f55e33136b333293d44b7e extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'canonical' => [$this, 'block_canonical'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'body_class' => [$this, 'block_body_class'],
            'page_title' => [$this, 'block_page_title'],
            'content' => [$this, 'block_content'],
            'javascript' => [$this, 'block_javascript'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<!DOCTYPE html>
<html lang=\"en\">
    <head>
        <meta charset=\"utf-8\" />
        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\" />
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\" />

        <title>";
        // line 8
        yield from $this->unwrap()->yieldBlock('title', $context, $blocks);
        yield " | Dotkernel Light</title>
        ";
        // line 9
        yield from $this->unwrap()->yieldBlock('canonical', $context, $blocks);
        // line 10
        yield "
        <link rel=\"apple-touch-icon\" sizes=\"180x180\" href=\"";
        // line 11
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Mezzio\Twig\TwigExtension']->renderAssetUrl("images/app/favicon/apple-touch-icon.png"), "html", null, true);
        yield "\">
        <link rel=\"icon\" type=\"image/png\" sizes=\"32x32\" href=\"";
        // line 12
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Mezzio\Twig\TwigExtension']->renderAssetUrl("images/app/favicon/favicon-32x32.png"), "html", null, true);
        yield "\">
        <link rel=\"icon\" type=\"image/png\" sizes=\"16x16\" href=\"";
        // line 13
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Mezzio\Twig\TwigExtension']->renderAssetUrl("images/app/favicon/favicon-16x16.png"), "html", null, true);
        yield "\">
        <link rel=\"manifest\" href=\"";
        // line 14
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Mezzio\Twig\TwigExtension']->renderAssetUrl("images/app/favicon/site.webmanifest"), "html", null, true);
        yield "\">
        <meta name=\"msapplication-TileColor\" content=\"#2d89ef\">
        <meta name=\"theme-color\" content=\"#ffffff\">

        <link href=\"https://use.fontawesome.com/releases/v5.0.6/css/all.css\" rel=\"stylesheet\" />
        <link href=\"https://fonts.googleapis.com/css?family=Montserrat:200,300,400\" rel=\"stylesheet\">
        <link href=\"https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400\" rel=\"stylesheet\">

        <link href=\"";
        // line 22
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Mezzio\Twig\TwigExtension']->renderAssetUrl("css/app.css"), "html", null, true);
        yield "\" rel=\"stylesheet\" />

        ";
        // line 24
        yield from $this->unwrap()->yieldBlock('stylesheets', $context, $blocks);
        // line 25
        yield "    </head>
    <body class=\"app ";
        // line 26
        yield from $this->unwrap()->yieldBlock('body_class', $context, $blocks);
        yield "\" data-bs-theme=\"light\">
        <div id=\"wrapper\">
            <header class=\"app-header\">

                <nav class=\"navbar navbar-expand-lg navbar-light bg-light\">
                    <div class=\"container\">
                        <a href=\"/\" class=\"navbar-brand\">
                            <img src=\"";
        // line 33
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Mezzio\Twig\TwigExtension']->renderAssetUrl("images/app/logo.svg"), "html", null, true);
        yield "\"
                                 onerror=\"this.onerror=null; this.src='";
        // line 34
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Mezzio\Twig\TwigExtension']->renderAssetUrl("images/app/logo.png"), "html", null, true);
        yield "';\"
                                 alt=\"Dotkernel\" />
                        </a>
                        <button class=\"navbar-toggler\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#navbarHeader\"
                                aria-controls=\"navbarHeader\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
                            <span class=\"navbar-toggler-icon\"></span>
                        </button>

                        <div class=\"collapse navbar-collapse\" id=\"navbarHeader\">
                            <ul class=\"navbar-nav me-auto\">
                                <li class=\"nav-item dropdown\">
                                    <a class=\"nav-link dropdown-toggle\" href=\"#\" id=\"pageDropdown\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">Pages</a>
                                    <div class=\"dropdown-menu\" aria-labelledby=\"pageDropdown\">
                                        <a class=\"dropdown-item\" href=\"";
        // line 47
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Mezzio\Twig\TwigExtension']->renderUrl("page::about"), "html", null, true);
        yield "\">About Us</a>
                                        <a class=\"dropdown-item\" href=\"";
        // line 48
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Mezzio\Twig\TwigExtension']->renderUrl("page::who-we-are"), "html", null, true);
        yield "\">Who We Are</a>
                                    </div>
                                </li>
                                <li class=\"nav-item\">
                                    <a class=\"nav-link\" href=\"https://github.com/dotkernel/light/\" target=\"_blank\">GitHub</a>
                                </li>
                                <li class=\"nav-item\">
                                    <a class=\"nav-link\" href=\"https://docs.dotkernel.org/light-documentation/\" target=\"_blank\">Documentation</a>
                                </li>
                                <li class=\"nav-item\">
                                    <a class=\"nav-link\" href=\"";
        // line 58
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Mezzio\Twig\TwigExtension']->renderUrl("app::paths-example"), "html", null, true);
        yield "\">Paths Example</a>
                                </li>
                                <li class=\"nav-item\">
                                    <a class=\"nav-link disabled\" href=\"";
        // line 61
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Mezzio\Twig\TwigExtension']->renderUrl("app::index"), "html", null, true);
        yield "\">Disabled</a>
                                </li>
                            </ul>

                            <!-- Theme Toggle -->
                            <div class=\"d-flex align-items-center\">
                                <span class=\"me-2 text-muted small\">Theme:</span>
                                <label class=\"theme-toggle\">
                                    <input type=\"checkbox\" id=\"themeToggle\">
                                    <span class=\"slider\"></span>
                                </label>
                            </div>
                        </div>
                    </div>
                </nav>
            </header>

            <!-- Content Wrapper. Contains page content -->
            <div class=\"app-content content-wrapper\">
                <!-- Content Header (Page header) -->
                <section class=\"content-header\">
                    ";
        // line 82
        yield from $this->unwrap()->yieldBlock('page_title', $context, $blocks);
        // line 83
        yield "                </section>

                <!-- Main content -->
                <section class=\"content\">
                    ";
        // line 87
        yield from $this->unwrap()->yieldBlock('content', $context, $blocks);
        // line 88
        yield "                </section>
            </div>

            <div id=\"push\"></div>
        </div>

        <footer class=\"app-footer\">
            <div class=\"container\">
                <p class=\"enjoy\">
                    enjoy dotkernel
                </p>
                <p>
                    © 2024 - ";
        // line 100
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extension\CoreExtension']->formatDate("now", "Y"), "html", null, true);
        yield " Dotkernel by Apidemia
                </p>
            </div>
        </footer>

        <script src=\"";
        // line 105
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Mezzio\Twig\TwigExtension']->renderAssetUrl("js/app.js"), "html", null, true);
        yield "\"></script>
        ";
        // line 106
        yield from $this->unwrap()->yieldBlock('javascript', $context, $blocks);
        // line 107
        yield "    </body>
</html>
";
        yield from [];
    }

    // line 8
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 9
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_canonical(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "<link rel=\"canonical\" href=\"";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Mezzio\Twig\TwigExtension']->renderUrl((((array_key_exists("routeName", $context) &&  !(null === $context["routeName"]))) ? ($context["routeName"]) : (null))), "html", null, true);
        yield "\" />";
        yield from [];
    }

    // line 24
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_stylesheets(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 26
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 82
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 87
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 106
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_javascript(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@layout/default.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  285 => 106,  275 => 87,  265 => 82,  255 => 26,  245 => 24,  232 => 9,  222 => 8,  215 => 107,  213 => 106,  209 => 105,  201 => 100,  187 => 88,  185 => 87,  179 => 83,  177 => 82,  153 => 61,  147 => 58,  134 => 48,  130 => 47,  114 => 34,  110 => 33,  100 => 26,  97 => 25,  95 => 24,  90 => 22,  79 => 14,  75 => 13,  71 => 12,  67 => 11,  64 => 10,  62 => 9,  58 => 8,  49 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@layout/default.html.twig", "/home/dan/Desktop/07/dk/light/src/App/templates/layout/default.html.twig");
    }
}
