# Shared Hosting Deployment Instructions

## Upload Files
1. Upload all files to your hosting account
2. Set document root to `/public/` directory (or upload public/ contents to public_html/)

## File Permissions
```bash
chmod 755 data/
chmod 755 logs/
chmod 644 data/*.db
```

## Database Setup
Databases are already included (user.db, mark.db) with default users:
- admin/admin123 (admin role)
- user/user123 (user role)
- mark/mark123 (mark role)

## Test URLs
- `/` - Home page
- `/user/login` - Login page
- `/user/dashboard` - Protected dashboard

## Troubleshooting
- Check file permissions if you get 500 errors
- Ensure PHP 8.1+ is available
- Check error logs in logs/ directory

## Security Notes
- Change default passwords after deployment
- Enable HTTPS in production
- Review session.local.php settings
