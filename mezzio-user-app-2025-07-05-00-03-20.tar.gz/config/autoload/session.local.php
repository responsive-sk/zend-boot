<?php
return [
    "session" => [
        "cookie_secure" => true,
        "cookie_httponly" => true,
        "cookie_samesite" => "Strict",
        "ini_settings" => [
            "session.gc_maxlifetime" => 3600,
            "session.cookie_lifetime" => 0,
            "session.use_strict_mode" => 1,
        ],
    ],
];
